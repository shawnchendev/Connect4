Group Name:
Diego Zuluaga
Meishang Chen

getwinner works
alpha_beta works
iterative_deeping_alpha_beta works
heuristic evaluation works
